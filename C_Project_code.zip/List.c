#include "List.h"

struct List* MakeList() {

	struct List* newList = (struct List*)malloc(sizeof(struct List));
	newList->IsEmpty = Empty;
	newList->Insert = InsertNode;
	newList->Delete = DeleteList;

	newList->head = NULL;
	newList->tail = NULL;

	return newList;
}

int Empty(struct List* list) {
	if (list->head == NULL && list->tail == NULL)
		return 1;
	else
		return 0;
}

struct Node* InsertNode(struct List* list, struct Node* node) {

	// ����Ʈ�� ��� ����
	// �迵��
	struct Node* ret;

	if (list->IsEmpty(list) == 1) {
		list->head = node;
		list->tail = node;
		ret = node;
	}
	else {
		list->tail->SetNodeNext(list->tail, node);
		list->tail = node;
		ret = node;
	}


	return ret;
}

void DeleteList(struct List* list) {
	struct Node* cur = list->head;
	while (!list->IsEmpty) {
		cur->DeleteNode(cur);
		cur = cur->pNext;
	}
}