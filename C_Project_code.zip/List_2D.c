#include "List_2D.h"


struct List_2D* MakeList_2D() {

	struct List_2D* newList = (struct List_2D*)malloc(sizeof(struct List_2D));
	newList->IsEmpty = Empty_2D;
	newList->Insert = InsertList;
	newList->Delete = DeleteList_2D;

	return newList;
}

int Empty_2D(struct List_2D* list) {
	if (!list->head && !list->tail)
		return 1;
	else
		return 0;
}

struct List* InsertList(struct List_2D* list_2d, struct List* list) {

	// ���μ�
	//
}

void DeleteList_2D(struct List_2D* list_2d) {
	
	// ���μ�
	//Deallocate 2D-List


}