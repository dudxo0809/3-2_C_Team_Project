#include "Manager.h"

int main() {

	// �׽��ÿ�
	/*
	struct Node* newNode = CreateNode();
	newNode->work = "PushUp";
	newNode->SetNodeSet(newNode, 3);
	newNode->SetTime(newNode, 10, 5);

	struct Node* newNode2 = CreateNode();
	newNode2->work = "LegRaise";
	newNode2->SetNodeSet(newNode2, 4);
	newNode2->SetTime(newNode2, 15, 10);

	struct List* newList = MakeList();
	newList->Insert(newList, newNode);
	newList->Insert(newList, newNode2);

	struct Node* cur;
	cur = newList->head;
	while (cur != NULL) {
		cur->WorkOut(cur);
		cur = cur->pNext;
	}
	*/
	//

	
	struct Manager manager;
	manager.run = Run;

	manager.run(manager);
	
	return 0;
}