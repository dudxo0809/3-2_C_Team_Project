#pragma once
#include "List.h"

struct List_2D {

	struct List* head;
	struct List* tail;

	int (*IsEmpty)(struct List_2D*);
	struct List_2D* (*Insert)(struct List*);
	void (*Delete)(struct List_2D*);		// Deallocate

};

struct List_2D* MakeList_2D();
int Empty_2D(struct List_2D*);
struct List* InsertList(struct List_2D* , struct List*);

void DeleteList_2D(struct List_2D*);