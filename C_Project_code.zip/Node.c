#include "Node.h"

struct Node* CreateNode() {

	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	newNode->work = (char*)malloc(sizeof(char) * 50);

	newNode->SetTime = SetNodeTime;
	newNode->SetNodeSet = SetNodeSet;
	newNode->SetNodeNext = SetNodeNext;
	newNode->PrintNode = Print;
	newNode->DeleteNode = Delete;
	newNode->WorkOut = Work;

	newNode->pNext = NULL;
	

	return newNode;
}

struct Node* SetNodeTime(struct Node* node, time_t work, time_t rest) {
	
	node->work_time = work;
	node->rest_time = rest;

	return node;
}

struct Node* SetNodeSet(struct Node* node, int set)
{
	node->set = set;
	return node;
}

struct Node* SetNodeNext(struct Node* node, struct Node* next)
{
	node->pNext = next;

	return node;
}

void Print(struct Node* node) {
	printf("%s\n", node->work);
}

void Delete(struct Node* node) {
	free(node->work);
}

void Work(struct Node* node) {

	// �Էµ� �ð��� �°� ȭ���� clear�ϸ鼭 timer ����
	// Using for(...) or while(...)

	// system("cls")	// �ܼ�â ����� ����
	// �迵��
	int current_set = 1;
	for (current_set = 1; current_set <= node->set; current_set++) {
		
		time_t timer = node->work_time;
		time_t rest = node->rest_time;

		for (; timer > 0; timer--) {
			system("cls");

			printf("===================================\n");
			printf("=                                  \n");
			printf("=           < Working >            \n");
			printf("=                                  \n");
			printf("=   Work  %s                       \n", node->work);
			printf("=                                  \n");
			printf("=   Set   %d set / %d set          \n", current_set, node->set);
			printf("=                                  \n");
			printf("=                                  \n");
			printf("=   Timer %lld sec / %lld sec      \n", timer, node->work_time);
			printf("=                                  \n");
			printf("=                                  \n");
			printf("=                                  \n");
			printf("===================================\n");
			
			Sleep(1000);
		}

		for (; rest > 0; rest--) {
			system("cls");

			printf("===================================\n");
			printf("=                                  \n");
			printf("=           < Resting >            \n");
			printf("=                                  \n");
			printf("=   Work  %s                       \n", node->work);
			printf("=                                  \n");
			printf("=   Set   %d set / %d set          \n", current_set, node->set);
			printf("=                                  \n");
			printf("=                                  \n");
			printf("=   Timer %lld sec / %lld sec      \n", rest, node->rest_time);
			printf("=                                  \n");
			printf("=                                  \n");
			printf("=                                  \n");
			printf("===================================\n");

			Sleep(1000);
		}

	}
	


}